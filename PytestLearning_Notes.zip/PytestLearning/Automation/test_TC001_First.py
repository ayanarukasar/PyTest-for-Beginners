def test_addition():
    assert 2 + 2 == 4

def test_substraction():
    assert 5 - 3 == 2

def test_multiplication():
    assert 5 - 3 == 2
